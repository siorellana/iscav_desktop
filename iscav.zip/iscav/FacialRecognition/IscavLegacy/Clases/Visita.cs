﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clases
{
  public class Visita
    {

        public int Id_visita { get; set; }
        public int Nombre { get; set; }
        public string ApellidoP { get; set; }
        public string ApellidoM { get; set; }
        public int Rut { get; set; }
        public int fecha_in { get; set; }
        public int Fecha_sal { get; set; }
    }
}
