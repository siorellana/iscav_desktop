﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clases
{
   public class Residente
    {

        public int Id_residente { get; set; }
        public int Nombre { get; set; }
        public int ApellidoP { get; set; }
        public int ApellidoM { get; set; }
        public string Direccion { get; set; }
        public string Correo { get; set; }
        public int Telefono { get; set; }
        public int Fecha_in { get; set; }
        public string Fecha_s { get; set; }
        public string Rut { get; set; }
    }
}
