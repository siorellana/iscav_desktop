﻿using FacialRecognition;
using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;

using System.Windows.Forms;

namespace Iscav1
{
    public partial class SelectMenu : Form
    {
        public SelectMenu()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            FrmEdificio Fredificio = new FrmEdificio();
            //propiedad.MdiParent = this;

           // propiedad.WindowState = FormWindowState.Maximized;
            Fredificio.Show();
            this.Hide();


        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            modPersona propietario = new modPersona();

           // propietario.MdiParent = this;

         //   propietario.WindowState = FormWindowState.Maximized;
            propietario.Show();
            this.Hide();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Reporte repo = new Reporte();

            //repo.MdiParent = this;

            repo.WindowState = FormWindowState.Maximized;
            repo.Show();

            pictureBox1.Hide();
            pictureBox2.Hide();
            pictureBox3.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            menuLogin login = new menuLogin();

            login.Show();

     
            this.Hide();
        }

        private void SelectMenu_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            modDepto modDepto = new modDepto();
            //propiedad.MdiParent = this;

            // propiedad.WindowState = FormWindowState.Maximized;
            modDepto.Show();
            this.Hide();

        }
    }
}
