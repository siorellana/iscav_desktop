﻿namespace Iscav1
{
    partial class modPersona
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(modPersona));
            this.tbpersonaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbprodDataSet = new FacialRecognition.dbprodDataSet();
            this.lblMensaje = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tbpersonaTableAdapter = new FacialRecognition.dbprodDataSetTableAdapters.tbpersonaTableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtDepto = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnBusNombre = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFaceId = new System.Windows.Forms.TextBox();
            this.btnBuscarDepto = new System.Windows.Forms.Button();
            this.btnMuestraTodo = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnResidentes = new System.Windows.Forms.Button();
            this.btnVisitas = new System.Windows.Forms.Button();
            this.dataGridPropietario = new System.Windows.Forms.DataGridView();
            this.faceidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deptoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipopersonaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fotoPersonaDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.activoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbpersonaBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dbprodDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbprodDataSet1 = new FacialRecognition.dbprodDataSet1();
            this.dbprodDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbpersonaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tbpersonaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tbresidenteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iscavDBDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iscavDBDataSet = new Iscav1.iscavDBDataSet();
            this.tbpersonaTableAdapter1 = new FacialRecognition.dbprodDataSet1TableAdapters.tbpersonaTableAdapter();
            this.tableAdapterManager = new FacialRecognition.dbprodDataSet1TableAdapters.TableAdapterManager();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMensaje1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tbpersonaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbprodDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPropietario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbpersonaBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbprodDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbprodDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbprodDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbpersonaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbpersonaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbresidenteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iscavDBDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iscavDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tbpersonaBindingSource
            // 
            this.tbpersonaBindingSource.DataMember = "tbpersona";
            this.tbpersonaBindingSource.DataSource = this.dbprodDataSet;
            // 
            // dbprodDataSet
            // 
            this.dbprodDataSet.DataSetName = "dbprodDataSet";
            this.dbprodDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblMensaje
            // 
            this.lblMensaje.AutoSize = true;
            this.lblMensaje.Location = new System.Drawing.Point(513, 20);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(0, 13);
            this.lblMensaje.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(196, 298);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 40);
            this.button1.TabIndex = 16;
            this.button1.Text = "Enrolar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(196, 356);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 40);
            this.button2.TabIndex = 17;
            this.button2.Text = "Verificar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tbpersonaTableAdapter
            // 
            this.tbpersonaTableAdapter.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(27, 442);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(95, 38);
            this.button4.TabIndex = 18;
            this.button4.Text = "Ver Personas Inactivas";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(402, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(538, 61);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(196, 20);
            this.txtNombre.TabIndex = 3;
            // 
            // txtDepto
            // 
            this.txtDepto.Location = new System.Drawing.Point(538, 96);
            this.txtDepto.Name = "txtDepto";
            this.txtDepto.Size = new System.Drawing.Size(195, 20);
            this.txtDepto.TabIndex = 6;
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnBuscar.Location = new System.Drawing.Point(749, 30);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(146, 23);
            this.btnBuscar.TabIndex = 11;
            this.btnBuscar.Text = "Buscar por FaceID";
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label5.Location = new System.Drawing.Point(402, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Departamento :";
            // 
            // btnBusNombre
            // 
            this.btnBusNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnBusNombre.Location = new System.Drawing.Point(749, 61);
            this.btnBusNombre.Name = "btnBusNombre";
            this.btnBusNombre.Size = new System.Drawing.Size(146, 23);
            this.btnBusNombre.TabIndex = 14;
            this.btnBusNombre.Text = "Buscar por Nombre";
            this.btnBusNombre.UseVisualStyleBackColor = false;
            this.btnBusNombre.Click += new System.EventHandler(this.btnBusNombre_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(403, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 18;
            this.label1.Text = "Face ID  :";
            // 
            // txtFaceId
            // 
            this.txtFaceId.Location = new System.Drawing.Point(538, 30);
            this.txtFaceId.Name = "txtFaceId";
            this.txtFaceId.Size = new System.Drawing.Size(100, 20);
            this.txtFaceId.TabIndex = 19;
            // 
            // btnBuscarDepto
            // 
            this.btnBuscarDepto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnBuscarDepto.Location = new System.Drawing.Point(749, 96);
            this.btnBuscarDepto.Name = "btnBuscarDepto";
            this.btnBuscarDepto.Size = new System.Drawing.Size(146, 23);
            this.btnBuscarDepto.TabIndex = 20;
            this.btnBuscarDepto.Text = "Buscar por Depto";
            this.btnBuscarDepto.UseVisualStyleBackColor = false;
            this.btnBuscarDepto.Click += new System.EventHandler(this.btnBuscarDepto_Click);
            // 
            // btnMuestraTodo
            // 
            this.btnMuestraTodo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnMuestraTodo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMuestraTodo.Location = new System.Drawing.Point(76, 116);
            this.btnMuestraTodo.Name = "btnMuestraTodo";
            this.btnMuestraTodo.Size = new System.Drawing.Size(157, 46);
            this.btnMuestraTodo.TabIndex = 8;
            this.btnMuestraTodo.Text = "Mostrar Personas Registradas";
            this.btnMuestraTodo.UseVisualStyleBackColor = false;
            this.btnMuestraTodo.Click += new System.EventHandler(this.btnMuestraTodo_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(210, 442);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 31);
            this.btnSalir.TabIndex = 7;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnResidentes
            // 
            this.btnResidentes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnResidentes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResidentes.Location = new System.Drawing.Point(76, 168);
            this.btnResidentes.Name = "btnResidentes";
            this.btnResidentes.Size = new System.Drawing.Size(157, 43);
            this.btnResidentes.TabIndex = 23;
            this.btnResidentes.Text = "Mostrar Residentes";
            this.btnResidentes.UseVisualStyleBackColor = false;
            this.btnResidentes.Click += new System.EventHandler(this.btnResidentes_Click);
            // 
            // btnVisitas
            // 
            this.btnVisitas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnVisitas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisitas.Location = new System.Drawing.Point(76, 217);
            this.btnVisitas.Name = "btnVisitas";
            this.btnVisitas.Size = new System.Drawing.Size(157, 42);
            this.btnVisitas.TabIndex = 22;
            this.btnVisitas.Text = "Mostrar Visitas";
            this.btnVisitas.UseVisualStyleBackColor = false;
            this.btnVisitas.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridPropietario
            // 
            this.dataGridPropietario.AllowUserToOrderColumns = true;
            this.dataGridPropietario.AutoGenerateColumns = false;
            this.dataGridPropietario.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridPropietario.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridPropietario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridPropietario.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.faceidDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn,
            this.deptoDataGridViewTextBoxColumn,
            this.tipopersonaDataGridViewTextBoxColumn,
            this.fotoPersonaDataGridViewImageColumn,
            this.activoDataGridViewTextBoxColumn});
            this.dataGridPropietario.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.dataGridPropietario.DataSource = this.tbpersonaBindingSource3;
            this.dataGridPropietario.GridColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.dataGridPropietario.Location = new System.Drawing.Point(301, 168);
            this.dataGridPropietario.Name = "dataGridPropietario";
            this.dataGridPropietario.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridPropietario.Size = new System.Drawing.Size(631, 334);
            this.dataGridPropietario.TabIndex = 25;
            this.dataGridPropietario.UseWaitCursor = true;
            // 
            // faceidDataGridViewTextBoxColumn
            // 
            this.faceidDataGridViewTextBoxColumn.DataPropertyName = "faceid";
            this.faceidDataGridViewTextBoxColumn.HeaderText = "FACE ID";
            this.faceidDataGridViewTextBoxColumn.Name = "faceidDataGridViewTextBoxColumn";
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "NOMBRE";
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            // 
            // deptoDataGridViewTextBoxColumn
            // 
            this.deptoDataGridViewTextBoxColumn.DataPropertyName = "depto";
            this.deptoDataGridViewTextBoxColumn.HeaderText = "DEPARTAMENTO";
            this.deptoDataGridViewTextBoxColumn.Name = "deptoDataGridViewTextBoxColumn";
            // 
            // tipopersonaDataGridViewTextBoxColumn
            // 
            this.tipopersonaDataGridViewTextBoxColumn.DataPropertyName = "tipopersona";
            this.tipopersonaDataGridViewTextBoxColumn.HeaderText = "TIPO PERSONA";
            this.tipopersonaDataGridViewTextBoxColumn.Name = "tipopersonaDataGridViewTextBoxColumn";
            // 
            // fotoPersonaDataGridViewImageColumn
            // 
            this.fotoPersonaDataGridViewImageColumn.DataPropertyName = "fotoPersona";
            this.fotoPersonaDataGridViewImageColumn.HeaderText = "FOTO";
            this.fotoPersonaDataGridViewImageColumn.Name = "fotoPersonaDataGridViewImageColumn";
            // 
            // activoDataGridViewTextBoxColumn
            // 
            this.activoDataGridViewTextBoxColumn.DataPropertyName = "activo";
            this.activoDataGridViewTextBoxColumn.HeaderText = "ESTADO";
            this.activoDataGridViewTextBoxColumn.Name = "activoDataGridViewTextBoxColumn";
            // 
            // tbpersonaBindingSource3
            // 
            this.tbpersonaBindingSource3.DataMember = "tbpersona";
            this.tbpersonaBindingSource3.DataSource = this.dbprodDataSet1BindingSource;
            // 
            // dbprodDataSet1BindingSource
            // 
            this.dbprodDataSet1BindingSource.DataSource = this.dbprodDataSet1;
            this.dbprodDataSet1BindingSource.Position = 0;
            // 
            // dbprodDataSet1
            // 
            this.dbprodDataSet1.DataSetName = "dbprodDataSet1";
            this.dbprodDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dbprodDataSetBindingSource
            // 
            this.dbprodDataSetBindingSource.DataSource = this.dbprodDataSet;
            this.dbprodDataSetBindingSource.Position = 0;
            // 
            // tbpersonaBindingSource1
            // 
            this.tbpersonaBindingSource1.DataMember = "tbpersona";
            this.tbpersonaBindingSource1.DataSource = this.dbprodDataSetBindingSource;
            // 
            // tbpersonaBindingSource2
            // 
            this.tbpersonaBindingSource2.DataMember = "tbpersona";
            this.tbpersonaBindingSource2.DataSource = this.dbprodDataSetBindingSource;
            // 
            // tbresidenteBindingSource
            // 
            this.tbresidenteBindingSource.DataMember = "tbresidente";
            this.tbresidenteBindingSource.DataSource = this.iscavDBDataSetBindingSource;
            // 
            // iscavDBDataSetBindingSource
            // 
            this.iscavDBDataSetBindingSource.DataSource = this.iscavDBDataSet;
            this.iscavDBDataSetBindingSource.Position = 0;
            // 
            // iscavDBDataSet
            // 
            this.iscavDBDataSet.DataSetName = "iscavDBDataSet";
            this.iscavDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbpersonaTableAdapter1
            // 
            this.tbpersonaTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tbdeptoTableAdapter = null;
            this.tableAdapterManager.tbedificioTableAdapter = null;
            this.tableAdapterManager.tbingresoTableAdapter = null;
            this.tableAdapterManager.tbpersonaTableAdapter = this.tbpersonaTableAdapter1;
            this.tableAdapterManager.UpdateOrder = FacialRecognition.dbprodDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::FacialRecognition.Properties.Resources._007_target;
            this.pictureBox2.Location = new System.Drawing.Point(358, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(27, 29);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 27;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(36, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(272, 80);
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(402, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 11;
            // 
            // lblMensaje1
            // 
            this.lblMensaje1.AutoSize = true;
            this.lblMensaje1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensaje1.ForeColor = System.Drawing.Color.Red;
            this.lblMensaje1.Location = new System.Drawing.Point(471, 148);
            this.lblMensaje1.Name = "lblMensaje1";
            this.lblMensaje1.Size = new System.Drawing.Size(0, 20);
            this.lblMensaje1.TabIndex = 28;
            // 
            // modPersona
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(213)))), ((int)(((byte)(237)))));
            this.CancelButton = this.btnSalir;
            this.ClientSize = new System.Drawing.Size(944, 517);
            this.Controls.Add(this.lblMensaje1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.dataGridPropietario);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnBuscarDepto);
            this.Controls.Add(this.btnResidentes);
            this.Controls.Add(this.txtFaceId);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnVisitas);
            this.Controls.Add(this.btnBusNombre);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblMensaje);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.txtDepto);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnMuestraTodo);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.Name = "modPersona";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Propietario";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.modPersona_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tbpersonaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbprodDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPropietario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbpersonaBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbprodDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbprodDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbprodDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbpersonaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbpersonaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbresidenteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iscavDBDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iscavDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblMensaje;
        private System.Windows.Forms.BindingSource iscavDBDataSetBindingSource;
        private iscavDBDataSet iscavDBDataSet;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
       // private System.Windows.Forms.DataGridViewTextBoxColumn idpropietarioDataGridViewTextBoxColumn;
      //  private System.Windows.Forms.DataGridViewTextBoxColumn edadDataGridViewTextBoxColumn;
        //private System.Windows.Forms.DataGridViewTextBoxColumn celularDataGridViewTextBoxColumn;
        //private System.Windows.Forms.DataGridViewTextBoxColumn fechainDataGridViewTextBoxColumn;
        private FacialRecognition.dbprodDataSet dbprodDataSet;
        private System.Windows.Forms.BindingSource tbpersonaBindingSource;
        private FacialRecognition.dbprodDataSetTableAdapters.tbpersonaTableAdapter tbpersonaTableAdapter;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtDepto;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnBusNombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFaceId;
        private System.Windows.Forms.Button btnBuscarDepto;
        private System.Windows.Forms.Button btnMuestraTodo;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnResidentes;
        private System.Windows.Forms.Button btnVisitas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridPropietario;
        private System.Windows.Forms.BindingSource dbprodDataSetBindingSource;
        private System.Windows.Forms.BindingSource tbpersonaBindingSource1;
        private FacialRecognition.dbprodDataSet1 dbprodDataSet1;
        private FacialRecognition.dbprodDataSet1TableAdapters.tbpersonaTableAdapter tbpersonaTableAdapter1;
        private FacialRecognition.dbprodDataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingSource dbprodDataSet1BindingSource;
        private System.Windows.Forms.BindingSource tbpersonaBindingSource2;
        private System.Windows.Forms.BindingSource tbresidenteBindingSource;
        private System.Windows.Forms.BindingSource tbpersonaBindingSource3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblMensaje1;
        private System.Windows.Forms.DataGridViewTextBoxColumn faceidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deptoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipopersonaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn fotoPersonaDataGridViewImageColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn activoDataGridViewTextBoxColumn;
    }
}