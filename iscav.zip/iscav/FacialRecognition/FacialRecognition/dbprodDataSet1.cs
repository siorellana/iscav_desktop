﻿namespace FacialRecognition
{
}

namespace FacialRecognition
{


    public partial class dbprodDataSet1
    {
    }
}
