﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Negocio;

namespace Iscav1
{
    public partial class Visita : Form
    {
        public Visita()
        {
            InitializeComponent();
        }
           protected void GvMostrar(object sender, EventArgs e)
        {

            //dataGridVisita.DataSource = AccesoLogica.ObtenerVisita();

            //txtRut.Enabled = true;

            //btnEnviar.Enabled = true;
        }
        
        private void btnBuscar_Click(object sender, EventArgs e)
        {

        }

        private void btnBuscarIDC_Click(object sender, EventArgs e)
        {

        }

        private void btnMostrarReser_Click(object sender, EventArgs e)
        {
            //dataGridVisita.DataSource = AccesoLogica.ObtenerVisita();
        }

        private void btnModReserva_Click(object sender, EventArgs e)
        {

        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void Visita_Load(object sender, EventArgs e)
        {

        }
    }
}
