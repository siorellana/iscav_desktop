﻿using System.Windows.Forms;

namespace FacialRecognition
{
    public partial class FrmPersona : Form
    {
        public FrmPersona()
        {
            InitializeComponent();
        }
    }
}
