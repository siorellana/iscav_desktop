﻿namespace FacialRecognition
{
    partial class modDepto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAtras = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnPiso4 = new System.Windows.Forms.Button();
            this.btnPiso3 = new System.Windows.Forms.Button();
            this.btnPiso2 = new System.Windows.Forms.Button();
            this.btnPiso1 = new System.Windows.Forms.Button();
            this.grpDeptos = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDetpo8 = new System.Windows.Forms.Button();
            this.btnDetpo6 = new System.Windows.Forms.Button();
            this.btnDetpo4 = new System.Windows.Forms.Button();
            this.btnDetpo2 = new System.Windows.Forms.Button();
            this.btnDetpo7 = new System.Windows.Forms.Button();
            this.btnDetpo5 = new System.Windows.Forms.Button();
            this.btnDetpo3 = new System.Windows.Forms.Button();
            this.btnDetpo1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.grpDeptos.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.groupBox1.Controls.Add(this.btnAtras);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(593, 75);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // btnAtras
            // 
            this.btnAtras.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnAtras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnAtras.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnAtras.Location = new System.Drawing.Point(434, 19);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(136, 32);
            this.btnAtras.TabIndex = 4;
            this.btnAtras.Text = "Volver a Menu";
            this.btnAtras.UseVisualStyleBackColor = false;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FacialRecognition.Properties.Resources.Logo_ISCAV;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(164, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(219)))), ((int)(((byte)(244)))));
            this.groupBox2.Controls.Add(this.btnPiso4);
            this.groupBox2.Controls.Add(this.btnPiso3);
            this.groupBox2.Controls.Add(this.btnPiso2);
            this.groupBox2.Controls.Add(this.btnPiso1);
            this.groupBox2.Location = new System.Drawing.Point(12, 105);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(192, 297);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // btnPiso4
            // 
            this.btnPiso4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnPiso4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPiso4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnPiso4.Location = new System.Drawing.Point(38, 214);
            this.btnPiso4.Name = "btnPiso4";
            this.btnPiso4.Size = new System.Drawing.Size(114, 42);
            this.btnPiso4.TabIndex = 3;
            this.btnPiso4.Text = "Piso 4";
            this.btnPiso4.UseVisualStyleBackColor = false;
            this.btnPiso4.Click += new System.EventHandler(this.btnPiso4_Click);
            // 
            // btnPiso3
            // 
            this.btnPiso3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnPiso3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPiso3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnPiso3.Location = new System.Drawing.Point(38, 147);
            this.btnPiso3.Name = "btnPiso3";
            this.btnPiso3.Size = new System.Drawing.Size(114, 42);
            this.btnPiso3.TabIndex = 2;
            this.btnPiso3.Text = "Piso 3";
            this.btnPiso3.UseVisualStyleBackColor = false;
            this.btnPiso3.Click += new System.EventHandler(this.btnPiso3_Click);
            // 
            // btnPiso2
            // 
            this.btnPiso2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnPiso2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPiso2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnPiso2.Location = new System.Drawing.Point(38, 85);
            this.btnPiso2.Name = "btnPiso2";
            this.btnPiso2.Size = new System.Drawing.Size(114, 42);
            this.btnPiso2.TabIndex = 1;
            this.btnPiso2.Text = "Piso 2";
            this.btnPiso2.UseVisualStyleBackColor = false;
            this.btnPiso2.Click += new System.EventHandler(this.btnPiso2_Click);
            // 
            // btnPiso1
            // 
            this.btnPiso1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnPiso1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPiso1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnPiso1.Location = new System.Drawing.Point(38, 19);
            this.btnPiso1.Name = "btnPiso1";
            this.btnPiso1.Size = new System.Drawing.Size(114, 42);
            this.btnPiso1.TabIndex = 0;
            this.btnPiso1.Text = "Piso 1";
            this.btnPiso1.UseVisualStyleBackColor = false;
            this.btnPiso1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grpDeptos
            // 
            this.grpDeptos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(219)))), ((int)(((byte)(244)))));
            this.grpDeptos.Controls.Add(this.label1);
            this.grpDeptos.Controls.Add(this.btnDetpo8);
            this.grpDeptos.Controls.Add(this.btnDetpo6);
            this.grpDeptos.Controls.Add(this.btnDetpo4);
            this.grpDeptos.Controls.Add(this.btnDetpo2);
            this.grpDeptos.Controls.Add(this.btnDetpo7);
            this.grpDeptos.Controls.Add(this.btnDetpo5);
            this.grpDeptos.Controls.Add(this.btnDetpo3);
            this.grpDeptos.Controls.Add(this.btnDetpo1);
            this.grpDeptos.Location = new System.Drawing.Point(240, 105);
            this.grpDeptos.Name = "grpDeptos";
            this.grpDeptos.Size = new System.Drawing.Size(330, 297);
            this.grpDeptos.TabIndex = 9;
            this.grpDeptos.TabStop = false;
            this.grpDeptos.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.label1.Location = new System.Drawing.Point(106, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Departamentos";
            // 
            // btnDetpo8
            // 
            this.btnDetpo8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnDetpo8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetpo8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnDetpo8.Location = new System.Drawing.Point(187, 247);
            this.btnDetpo8.Name = "btnDetpo8";
            this.btnDetpo8.Size = new System.Drawing.Size(95, 42);
            this.btnDetpo8.TabIndex = 7;
            this.btnDetpo8.Text = "btnDetpo8";
            this.btnDetpo8.UseVisualStyleBackColor = false;
            this.btnDetpo8.Click += new System.EventHandler(this.btnDetpo8_Click);
            // 
            // btnDetpo6
            // 
            this.btnDetpo6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnDetpo6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetpo6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnDetpo6.Location = new System.Drawing.Point(187, 176);
            this.btnDetpo6.Name = "btnDetpo6";
            this.btnDetpo6.Size = new System.Drawing.Size(95, 42);
            this.btnDetpo6.TabIndex = 6;
            this.btnDetpo6.Text = "btnDetpo6";
            this.btnDetpo6.UseVisualStyleBackColor = false;
            this.btnDetpo6.Click += new System.EventHandler(this.btnDetpo6_Click);
            // 
            // btnDetpo4
            // 
            this.btnDetpo4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnDetpo4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetpo4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnDetpo4.Location = new System.Drawing.Point(187, 101);
            this.btnDetpo4.Name = "btnDetpo4";
            this.btnDetpo4.Size = new System.Drawing.Size(95, 42);
            this.btnDetpo4.TabIndex = 5;
            this.btnDetpo4.Text = "btnDetpo4";
            this.btnDetpo4.UseVisualStyleBackColor = false;
            this.btnDetpo4.Click += new System.EventHandler(this.btnDetpo4_Click);
            // 
            // btnDetpo2
            // 
            this.btnDetpo2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnDetpo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetpo2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnDetpo2.Location = new System.Drawing.Point(187, 35);
            this.btnDetpo2.Name = "btnDetpo2";
            this.btnDetpo2.Size = new System.Drawing.Size(95, 42);
            this.btnDetpo2.TabIndex = 4;
            this.btnDetpo2.Text = "btnDetpo2";
            this.btnDetpo2.UseVisualStyleBackColor = false;
            this.btnDetpo2.Click += new System.EventHandler(this.btnDetpo2_Click);
            // 
            // btnDetpo7
            // 
            this.btnDetpo7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnDetpo7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetpo7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnDetpo7.Location = new System.Drawing.Point(37, 247);
            this.btnDetpo7.Name = "btnDetpo7";
            this.btnDetpo7.Size = new System.Drawing.Size(95, 42);
            this.btnDetpo7.TabIndex = 3;
            this.btnDetpo7.Text = "btnDetpo7";
            this.btnDetpo7.UseVisualStyleBackColor = false;
            this.btnDetpo7.Click += new System.EventHandler(this.btnDetpo7_Click);
            // 
            // btnDetpo5
            // 
            this.btnDetpo5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnDetpo5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetpo5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnDetpo5.Location = new System.Drawing.Point(37, 176);
            this.btnDetpo5.Name = "btnDetpo5";
            this.btnDetpo5.Size = new System.Drawing.Size(95, 42);
            this.btnDetpo5.TabIndex = 2;
            this.btnDetpo5.Text = "btnDetpo5";
            this.btnDetpo5.UseVisualStyleBackColor = false;
            this.btnDetpo5.Click += new System.EventHandler(this.btnDetpo5_Click);
            // 
            // btnDetpo3
            // 
            this.btnDetpo3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnDetpo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetpo3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnDetpo3.Location = new System.Drawing.Point(37, 101);
            this.btnDetpo3.Name = "btnDetpo3";
            this.btnDetpo3.Size = new System.Drawing.Size(95, 42);
            this.btnDetpo3.TabIndex = 1;
            this.btnDetpo3.Text = "btnDetpo3";
            this.btnDetpo3.UseVisualStyleBackColor = false;
            this.btnDetpo3.Click += new System.EventHandler(this.btnDetpo3_Click);
            // 
            // btnDetpo1
            // 
            this.btnDetpo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(151)))), ((int)(((byte)(0)))));
            this.btnDetpo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetpo1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(82)))), ((int)(((byte)(122)))));
            this.btnDetpo1.Location = new System.Drawing.Point(37, 35);
            this.btnDetpo1.Name = "btnDetpo1";
            this.btnDetpo1.Size = new System.Drawing.Size(95, 42);
            this.btnDetpo1.TabIndex = 0;
            this.btnDetpo1.Text = "btnDetpo1";
            this.btnDetpo1.UseVisualStyleBackColor = false;
            this.btnDetpo1.Click += new System.EventHandler(this.btnDetpo1_Click);
            // 
            // modDepto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 427);
            this.Controls.Add(this.grpDeptos);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "modDepto";
            this.Text = "modDepto";
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.grpDeptos.ResumeLayout(false);
            this.grpDeptos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnAtras;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnPiso4;
        private System.Windows.Forms.Button btnPiso3;
        private System.Windows.Forms.Button btnPiso2;
        private System.Windows.Forms.Button btnPiso1;
        private System.Windows.Forms.GroupBox grpDeptos;
        private System.Windows.Forms.Button btnDetpo8;
        private System.Windows.Forms.Button btnDetpo6;
        private System.Windows.Forms.Button btnDetpo4;
        private System.Windows.Forms.Button btnDetpo2;
        private System.Windows.Forms.Button btnDetpo7;
        private System.Windows.Forms.Button btnDetpo5;
        private System.Windows.Forms.Button btnDetpo3;
        private System.Windows.Forms.Button btnDetpo1;
        private System.Windows.Forms.Label label1;
    }
}