﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clases
{
   public class Propietario
    {

        public int id_propietaio { get; set; }
        public string nombre { get; set; }
        public string Apellido { get; set; }
        public string edad { get; set; }
        public string cant_propiedades { get; set; }
        public string celular { get; set; }
        public string correo { get; set; }
        public string fecha_in { get; set; }
        public int apellidoM { get; set; }
        public string rut { get; set; }
    }
}
