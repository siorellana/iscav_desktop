﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clases
{
    public class User
    {


        //public string user { get; set; }
        //public string pass { get; set; }
    }
}
